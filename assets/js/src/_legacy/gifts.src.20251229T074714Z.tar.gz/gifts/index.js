/**
 * Gifts entry with robust import + forced mount after builder renders.
 */
import * as FCmod from './free-choices';

// Normalize export shape
const FreeChoices = (FCmod && (FCmod.default || FCmod)) || {};
const fn = (o,k)=> (typeof o?.[k]==='function' ? o[k].bind(o) : ()=>{});

export function init()    { fn(FreeChoices,'init')(); }
export function refresh() { fn(FreeChoices,'refresh')(); }
export function getSelected() {
  const st = (window.CG_FreeChoicesState && Array.isArray(window.CG_FreeChoicesState.selected))
    ? window.CG_FreeChoicesState.selected : [];
  return st;
}

// Default API (what core imports)
const GiftsAPI = { init, refresh, getSelected };
export default GiftsAPI;

// Force a mount if the section isn't there yet
function forceMount() {
  // If already present, nothing to do
  if (document.getElementById('cg-free-gifts')) return;

  // Preferred: call the real internal mount (it wires listeners/observer)
  if (typeof FreeChoices?._tryMount === 'function') {
    try { FreeChoices._tryMount(); } catch (e) { /* no-op */ }
  }

  // If _tryMount didn't create it, last-resort fallback into the builder container
  if (!document.getElementById('cg-free-gifts')) {
    const container = document.querySelector('#cg-form-container') || document.body;
    const section = document.createElement('section');
    section.id = 'cg-free-gifts';
    section.className = 'cg-block';
    section.innerHTML = `
      <h3>Free Gift</h3>
      <div class="cg-free-chosen">
        <label>Chosen</label>
        <select class="cg-free-select" data-slot="0"></select>
        <select class="cg-free-select" data-slot="1"></select>
        <select class="cg-free-select" data-slot="2"></select>
      </div>`;
    container.appendChild(section);
  }
}

function boot() {
  init();
  // Give the builder time to render, then enforce mount
  setTimeout(forceMount, 200);
  setTimeout(forceMount, 600);  // second pass after async panels
}

// Boot on key lifecycle events
['DOMContentLoaded','cg:builder:open','cg:builder:ready'].forEach(evt => {
  document.addEventListener(evt, boot);
});

// Debug: inspect in console as window.CG_FreeChoices
window.CG_FreeChoices = FreeChoices;
